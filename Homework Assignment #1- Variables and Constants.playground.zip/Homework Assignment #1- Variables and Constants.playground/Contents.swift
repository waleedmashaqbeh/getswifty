import UIKit


var songName : String = "Sweet but Psycho - Single"
var artist   : String  = "Ava Max"
let formatter = DateFormatter()
formatter.dateFormat = "yyyy/MM/dd HH:mm"
let releaseDate = formatter.date(from: "2018/08/17 00:00")
var unitPrice    : Double = 1.4
var currency     : Character = "$"
var price        : String    = String(currency) + " " + String(unitPrice)








